.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.tools.drawing
===========================


.. automodule:: moviepy.video.tools.drawing

   

   
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      blit
      circle
      color_gradient
      color_split
   
   


   
   
   



