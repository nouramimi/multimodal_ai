moviepy.tools.cross\_platform\_popen\_params
============================================

.. currentmodule:: moviepy.tools

.. autofunction:: cross_platform_popen_params