.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.io.ffmpeg\_tools
==============================


.. automodule:: moviepy.video.io.ffmpeg_tools

   

   
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      ffmpeg_extract_audio
      ffmpeg_extract_subclip
      ffmpeg_merge_video_audio
      ffmpeg_resize
      ffmpeg_stabilize_video
   
   


   
   
   



