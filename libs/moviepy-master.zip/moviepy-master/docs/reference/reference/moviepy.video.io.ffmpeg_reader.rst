.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.io.ffmpeg\_reader
===============================


.. automodule:: moviepy.video.io.ffmpeg_reader

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      FFMPEG_VideoReader
      FFmpegInfosParser
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      ffmpeg_parse_infos
      ffmpeg_read_image
   
   


   
   
   



