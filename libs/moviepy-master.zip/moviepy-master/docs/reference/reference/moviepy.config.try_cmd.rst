moviepy.config.try\_cmd
=======================

.. currentmodule:: moviepy.config

.. autofunction:: try_cmd