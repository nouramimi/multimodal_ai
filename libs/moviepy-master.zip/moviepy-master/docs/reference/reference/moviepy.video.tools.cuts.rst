.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.tools.cuts
========================


.. automodule:: moviepy.video.tools.cuts

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      FramesMatch
      FramesMatches
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      detect_scenes
      find_video_period
   
   


   
   
   



