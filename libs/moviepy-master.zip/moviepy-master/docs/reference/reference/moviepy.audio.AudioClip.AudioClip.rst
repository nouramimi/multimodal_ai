.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.audio.AudioClip.AudioClip
=================================

.. currentmodule:: moviepy.audio.AudioClip

.. autoclass:: AudioClip
   :members:

   