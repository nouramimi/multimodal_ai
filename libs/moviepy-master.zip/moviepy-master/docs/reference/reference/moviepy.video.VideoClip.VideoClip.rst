.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.video.VideoClip.VideoClip
=================================

.. currentmodule:: moviepy.video.VideoClip

.. autoclass:: VideoClip
   :members:

   