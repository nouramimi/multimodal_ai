moviepy.tools.convert\_to\_seconds
==================================

.. currentmodule:: moviepy.tools

.. autofunction:: convert_to_seconds