moviepy.video.tools.drawing.circle
==================================

.. currentmodule:: moviepy.video.tools.drawing

.. autofunction:: circle