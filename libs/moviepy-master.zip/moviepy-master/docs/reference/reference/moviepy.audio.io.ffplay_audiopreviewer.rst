.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.audio.io.ffplay\_audiopreviewer
=======================================


.. automodule:: moviepy.audio.io.ffplay_audiopreviewer

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      FFPLAY_AudioPreviewer
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      ffplay_audiopreview
   
   


   
   
   



