moviepy.video.tools.cuts.detect\_scenes
=======================================

.. currentmodule:: moviepy.video.tools.cuts

.. autofunction:: detect_scenes