moviepy.video.io.display\_in\_notebook.display\_in\_notebook
============================================================

.. currentmodule:: moviepy.video.io.display_in_notebook

.. autofunction:: display_in_notebook