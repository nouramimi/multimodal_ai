moviepy.video.io.ffmpeg\_reader.ffmpeg\_parse\_infos
====================================================

.. currentmodule:: moviepy.video.io.ffmpeg_reader

.. autofunction:: ffmpeg_parse_infos