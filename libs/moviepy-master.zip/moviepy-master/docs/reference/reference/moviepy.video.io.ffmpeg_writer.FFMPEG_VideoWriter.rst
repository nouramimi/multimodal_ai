.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.video.io.ffmpeg\_writer.FFMPEG\_VideoWriter
===================================================

.. currentmodule:: moviepy.video.io.ffmpeg_writer

.. autoclass:: FFMPEG_VideoWriter
   :members:

   