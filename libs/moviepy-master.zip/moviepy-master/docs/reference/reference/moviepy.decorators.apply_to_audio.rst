moviepy.decorators.apply\_to\_audio
===================================

.. currentmodule:: moviepy.decorators

.. autofunction:: apply_to_audio