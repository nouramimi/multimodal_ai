moviepy.video.io.ffmpeg\_tools.ffmpeg\_stabilize\_video
=======================================================

.. currentmodule:: moviepy.video.io.ffmpeg_tools

.. autofunction:: ffmpeg_stabilize_video