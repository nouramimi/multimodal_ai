.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.video.tools.interpolators.Interpolator
==============================================

.. currentmodule:: moviepy.video.tools.interpolators

.. autoclass:: Interpolator
   :members:

   