moviepy.video.io.ffmpeg\_writer.ffmpeg\_write\_image
====================================================

.. currentmodule:: moviepy.video.io.ffmpeg_writer

.. autofunction:: ffmpeg_write_image