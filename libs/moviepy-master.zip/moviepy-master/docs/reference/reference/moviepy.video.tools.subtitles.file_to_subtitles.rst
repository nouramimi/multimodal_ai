moviepy.video.tools.subtitles.file\_to\_subtitles
=================================================

.. currentmodule:: moviepy.video.tools.subtitles

.. autofunction:: file_to_subtitles