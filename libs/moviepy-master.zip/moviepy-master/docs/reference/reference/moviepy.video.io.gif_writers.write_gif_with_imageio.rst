moviepy.video.io.gif\_writers.write\_gif\_with\_imageio
=======================================================

.. currentmodule:: moviepy.video.io.gif_writers

.. autofunction:: write_gif_with_imageio