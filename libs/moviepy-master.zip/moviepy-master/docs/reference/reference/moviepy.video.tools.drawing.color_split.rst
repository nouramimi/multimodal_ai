moviepy.video.tools.drawing.color\_split
========================================

.. currentmodule:: moviepy.video.tools.drawing

.. autofunction:: color_split