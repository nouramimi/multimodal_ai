moviepy.tools.subprocess\_call
==============================

.. currentmodule:: moviepy.tools

.. autofunction:: subprocess_call