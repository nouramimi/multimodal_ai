moviepy.config.check
====================

.. currentmodule:: moviepy.config

.. autofunction:: check