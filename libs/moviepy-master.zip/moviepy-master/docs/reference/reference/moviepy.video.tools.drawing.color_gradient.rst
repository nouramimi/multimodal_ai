moviepy.video.tools.drawing.color\_gradient
===========================================

.. currentmodule:: moviepy.video.tools.drawing

.. autofunction:: color_gradient