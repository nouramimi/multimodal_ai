.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.audio.io.AudioFileClip
==============================


.. automodule:: moviepy.audio.io.AudioFileClip

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      AudioFileClip
   
   


   
   
   


   
   
   



