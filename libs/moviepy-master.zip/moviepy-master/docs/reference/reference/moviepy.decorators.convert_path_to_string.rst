moviepy.decorators.convert\_path\_to\_string
============================================

.. currentmodule:: moviepy.decorators

.. autofunction:: convert_path_to_string