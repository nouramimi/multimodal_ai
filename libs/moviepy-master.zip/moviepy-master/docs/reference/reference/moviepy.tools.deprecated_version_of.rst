moviepy.tools.deprecated\_version\_of
=====================================

.. currentmodule:: moviepy.tools

.. autofunction:: deprecated_version_of