moviepy.video.compositing.CompositeVideoClip.clips\_array
=========================================================

.. currentmodule:: moviepy.video.compositing.CompositeVideoClip

.. autofunction:: clips_array