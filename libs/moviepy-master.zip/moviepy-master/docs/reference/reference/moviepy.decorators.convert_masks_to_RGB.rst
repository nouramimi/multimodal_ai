moviepy.decorators.convert\_masks\_to\_RGB
==========================================

.. currentmodule:: moviepy.decorators

.. autofunction:: convert_masks_to_RGB