moviepy.video.io.ffplay\_previewer.ffplay\_preview\_video
=========================================================

.. currentmodule:: moviepy.video.io.ffplay_previewer

.. autofunction:: ffplay_preview_video