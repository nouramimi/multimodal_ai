moviepy.audio.io.ffmpeg\_audiowriter.ffmpeg\_audiowrite
=======================================================

.. currentmodule:: moviepy.audio.io.ffmpeg_audiowriter

.. autofunction:: ffmpeg_audiowrite