moviepy.decorators.preprocess\_args
===================================

.. currentmodule:: moviepy.decorators

.. autofunction:: preprocess_args