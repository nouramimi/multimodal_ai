moviepy.video.tools.drawing.blit
================================

.. currentmodule:: moviepy.video.tools.drawing

.. autofunction:: blit