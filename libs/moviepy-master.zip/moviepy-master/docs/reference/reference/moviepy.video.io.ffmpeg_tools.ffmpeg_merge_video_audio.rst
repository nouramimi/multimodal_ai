moviepy.video.io.ffmpeg\_tools.ffmpeg\_merge\_video\_audio
==========================================================

.. currentmodule:: moviepy.video.io.ffmpeg_tools

.. autofunction:: ffmpeg_merge_video_audio