moviepy.decorators.apply\_to\_mask
==================================

.. currentmodule:: moviepy.decorators

.. autofunction:: apply_to_mask