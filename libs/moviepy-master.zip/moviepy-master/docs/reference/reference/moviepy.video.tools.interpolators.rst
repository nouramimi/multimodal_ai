.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.tools.interpolators
=================================


.. automodule:: moviepy.video.tools.interpolators

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      Interpolator
      Trajectory
   
   


   
   
   


   
   
   



