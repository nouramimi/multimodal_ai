.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.audio.AudioClip.CompositeAudioClip
==========================================

.. currentmodule:: moviepy.audio.AudioClip

.. autoclass:: CompositeAudioClip
   :members:

   