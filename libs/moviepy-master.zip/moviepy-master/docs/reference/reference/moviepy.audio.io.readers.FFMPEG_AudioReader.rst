.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.audio.io.readers.FFMPEG\_AudioReader
============================================

.. currentmodule:: moviepy.audio.io.readers

.. autoclass:: FFMPEG_AudioReader
   :members:

   