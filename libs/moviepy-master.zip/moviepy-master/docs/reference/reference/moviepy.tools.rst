﻿.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.tools
=============


.. automodule:: moviepy.tools

   

   
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      close_all_clips
      convert_to_seconds
      cross_platform_popen_params
      deprecated_version_of
      find_extension
      no_display_available
      subprocess_call
   
   


   
   
   



