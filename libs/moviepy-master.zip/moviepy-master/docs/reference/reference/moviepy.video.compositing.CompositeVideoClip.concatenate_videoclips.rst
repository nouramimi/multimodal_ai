moviepy.video.compositing.CompositeVideoClip.concatenate\_videoclips
====================================================================

.. currentmodule:: moviepy.video.compositing.CompositeVideoClip

.. autofunction:: concatenate_videoclips