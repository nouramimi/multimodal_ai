.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.video.io.ffmpeg\_reader.FFmpegInfosParser
=================================================

.. currentmodule:: moviepy.video.io.ffmpeg_reader

.. autoclass:: FFmpegInfosParser
   :members:

   