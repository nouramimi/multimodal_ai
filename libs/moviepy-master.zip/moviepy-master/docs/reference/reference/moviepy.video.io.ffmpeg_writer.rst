.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.io.ffmpeg\_writer
===============================


.. automodule:: moviepy.video.io.ffmpeg_writer

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      FFMPEG_VideoWriter
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      ffmpeg_write_image
      ffmpeg_write_video
   
   


   
   
   



