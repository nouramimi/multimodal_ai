moviepy.decorators.outplace
===========================

.. currentmodule:: moviepy.decorators

.. autofunction:: outplace