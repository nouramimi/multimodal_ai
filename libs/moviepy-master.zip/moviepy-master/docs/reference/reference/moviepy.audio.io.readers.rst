.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.audio.io.readers
========================


.. automodule:: moviepy.audio.io.readers

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      FFMPEG_AudioReader
   
   


   
   
   


   
   
   



