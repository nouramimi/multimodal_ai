.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.io.ffplay\_previewer
==================================


.. automodule:: moviepy.video.io.ffplay_previewer

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      FFPLAY_VideoPreviewer
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      ffplay_preview_video
   
   


   
   
   



