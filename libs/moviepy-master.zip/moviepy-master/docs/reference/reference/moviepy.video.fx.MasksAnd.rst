.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.fx.MasksAnd
=========================

 
.. automodule:: moviepy.video.fx.MasksAnd
   :inherited-members:

   

   
   
   


   
   
   


   
   
   



