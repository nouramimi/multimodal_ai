moviepy.video.tools.cuts.find\_video\_period
============================================

.. currentmodule:: moviepy.video.tools.cuts

.. autofunction:: find_video_period