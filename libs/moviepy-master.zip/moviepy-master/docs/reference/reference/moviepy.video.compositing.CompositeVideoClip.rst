.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.compositing.CompositeVideoClip
============================================


.. automodule:: moviepy.video.compositing.CompositeVideoClip

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      CompositeVideoClip
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      clips_array
      concatenate_videoclips
   
   


   
   
   



