.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.audio.io.ffmpeg\_audiowriter.FFMPEG\_AudioWriter
========================================================

.. currentmodule:: moviepy.audio.io.ffmpeg_audiowriter

.. autoclass:: FFMPEG_AudioWriter
   :members:

   