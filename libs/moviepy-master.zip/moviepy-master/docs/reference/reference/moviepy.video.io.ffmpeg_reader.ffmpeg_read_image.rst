moviepy.video.io.ffmpeg\_reader.ffmpeg\_read\_image
===================================================

.. currentmodule:: moviepy.video.io.ffmpeg_reader

.. autofunction:: ffmpeg_read_image