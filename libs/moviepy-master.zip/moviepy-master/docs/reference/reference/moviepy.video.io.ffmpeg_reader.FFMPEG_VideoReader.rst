.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.video.io.ffmpeg\_reader.FFMPEG\_VideoReader
===================================================

.. currentmodule:: moviepy.video.io.ffmpeg_reader

.. autoclass:: FFMPEG_VideoReader
   :members:

   