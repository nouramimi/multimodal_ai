moviepy.video.io.ffmpeg\_tools.ffmpeg\_extract\_audio
=====================================================

.. currentmodule:: moviepy.video.io.ffmpeg_tools

.. autofunction:: ffmpeg_extract_audio