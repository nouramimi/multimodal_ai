.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.audio.tools.cuts
========================


.. automodule:: moviepy.audio.tools.cuts

   

   
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      find_audio_period
   
   


   
   
   



