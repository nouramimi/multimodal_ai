.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.compositing
=========================


.. automodule:: moviepy.video.compositing

   

   
   
   


   
   
   


   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree:
   :template: custom_autosummary/module.rst
   :recursive:


   moviepy.video.compositing.CompositeVideoClip


