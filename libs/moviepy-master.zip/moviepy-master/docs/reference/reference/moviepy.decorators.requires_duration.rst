moviepy.decorators.requires\_duration
=====================================

.. currentmodule:: moviepy.decorators

.. autofunction:: requires_duration