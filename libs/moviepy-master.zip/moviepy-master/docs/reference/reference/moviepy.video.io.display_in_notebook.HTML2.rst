.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.video.io.display\_in\_notebook.HTML2
============================================

.. currentmodule:: moviepy.video.io.display_in_notebook

.. autoclass:: HTML2
   :members:

   