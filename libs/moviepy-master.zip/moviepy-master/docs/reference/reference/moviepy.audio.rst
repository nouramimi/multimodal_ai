.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.audio
=============


.. automodule:: moviepy.audio

   

   
   
   


   
   
   


   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree:
   :template: custom_autosummary/module.rst
   :recursive:


   moviepy.audio.AudioClip


   moviepy.audio.fx


   moviepy.audio.io


   moviepy.audio.tools


