moviepy.decorators.requires\_fps
================================

.. currentmodule:: moviepy.decorators

.. autofunction:: requires_fps