moviepy.decorators.add\_mask\_if\_none
======================================

.. currentmodule:: moviepy.decorators

.. autofunction:: add_mask_if_none