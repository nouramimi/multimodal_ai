moviepy.tools.close\_all\_clips
===============================

.. currentmodule:: moviepy.tools

.. autofunction:: close_all_clips