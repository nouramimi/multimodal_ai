moviepy.audio.io.ffplay\_audiopreviewer.ffplay\_audiopreview
============================================================

.. currentmodule:: moviepy.audio.io.ffplay_audiopreviewer

.. autofunction:: ffplay_audiopreview