.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.audio.io.ffplay\_audiopreviewer.FFPLAY\_AudioPreviewer
==============================================================

.. currentmodule:: moviepy.audio.io.ffplay_audiopreviewer

.. autoclass:: FFPLAY_AudioPreviewer
   :members:

   