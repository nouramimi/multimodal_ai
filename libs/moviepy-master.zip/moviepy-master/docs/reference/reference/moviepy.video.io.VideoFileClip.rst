.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.io.VideoFileClip
==============================


.. automodule:: moviepy.video.io.VideoFileClip

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      VideoFileClip
   
   


   
   
   


   
   
   



