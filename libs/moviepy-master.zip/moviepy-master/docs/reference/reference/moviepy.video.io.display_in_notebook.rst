.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.video.io.display\_in\_notebook
======================================


.. automodule:: moviepy.video.io.display_in_notebook

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      HTML2
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      display_in_notebook
      html_embed
   
   


   
   
   



