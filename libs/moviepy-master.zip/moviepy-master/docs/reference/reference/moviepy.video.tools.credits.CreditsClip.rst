.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.video.tools.credits.CreditsClip
=======================================

.. currentmodule:: moviepy.video.tools.credits

.. autoclass:: CreditsClip
   :members:

   