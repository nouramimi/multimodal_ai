moviepy.video.io.display\_in\_notebook.html\_embed
==================================================

.. currentmodule:: moviepy.video.io.display_in_notebook

.. autofunction:: html_embed