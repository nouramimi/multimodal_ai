moviepy.tools.find\_extension
=============================

.. currentmodule:: moviepy.tools

.. autofunction:: find_extension