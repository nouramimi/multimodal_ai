moviepy.decorators.use\_clip\_fps\_by\_default
==============================================

.. currentmodule:: moviepy.decorators

.. autofunction:: use_clip_fps_by_default