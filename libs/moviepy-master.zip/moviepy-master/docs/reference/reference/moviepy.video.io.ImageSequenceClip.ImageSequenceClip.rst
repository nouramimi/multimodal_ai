.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.video.io.ImageSequenceClip.ImageSequenceClip
====================================================

.. currentmodule:: moviepy.video.io.ImageSequenceClip

.. autoclass:: ImageSequenceClip
   :members:

   