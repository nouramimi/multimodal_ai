moviepy.video.io.ffmpeg\_tools.ffmpeg\_resize
=============================================

.. currentmodule:: moviepy.video.io.ffmpeg_tools

.. autofunction:: ffmpeg_resize