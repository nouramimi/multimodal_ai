.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.audio.fx.MultiplyVolume
===============================

 
.. automodule:: moviepy.audio.fx.MultiplyVolume
   :inherited-members:

   

   
   
   


   
   
   


   
   
   



