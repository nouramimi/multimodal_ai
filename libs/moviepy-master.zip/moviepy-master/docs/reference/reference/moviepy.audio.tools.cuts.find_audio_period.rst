moviepy.audio.tools.cuts.find\_audio\_period
============================================

.. currentmodule:: moviepy.audio.tools.cuts

.. autofunction:: find_audio_period