moviepy.decorators.audio\_video\_effect
=======================================

.. currentmodule:: moviepy.decorators

.. autofunction:: audio_video_effect