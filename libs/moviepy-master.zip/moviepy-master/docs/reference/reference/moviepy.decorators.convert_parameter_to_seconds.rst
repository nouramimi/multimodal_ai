moviepy.decorators.convert\_parameter\_to\_seconds
==================================================

.. currentmodule:: moviepy.decorators

.. autofunction:: convert_parameter_to_seconds