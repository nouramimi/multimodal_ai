.. custom class to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202

moviepy.audio.io.AudioFileClip.AudioFileClip
============================================

.. currentmodule:: moviepy.audio.io.AudioFileClip

.. autoclass:: AudioFileClip
   :members:

   