.. custom module to enable complete documentation of every function
   see https://stackoverflow.com/a/62613202
   
moviepy.audio.io.ffmpeg\_audiowriter
====================================


.. automodule:: moviepy.audio.io.ffmpeg_audiowriter

   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom_autosummary/class.rst
   
      FFMPEG_AudioWriter
   
   


   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      ffmpeg_audiowrite
   
   


   
   
   



