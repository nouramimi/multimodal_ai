.. _developer_guide:

The MoviePy Developer's Guide
-----------------------------

This guide covers most of the things people wanting to participate in MoviePy development need to know.

.. toctree::
   :maxdepth: 1
   
   developers_install
   contribution_guidelines
   maintainers_publish
