Install testing dependencies: `pip install moviepy[test]`

Run tests: `pytest`
